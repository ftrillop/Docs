# Práctica 5.1 - Preferencias de usuario, cookies

Archivos:
* **practica1-index.php**. Formulario de selección de preferencias
* **practica1-borrar.php**. Borrado de las preferencias
* **practica1-comprobar.php**. Comprueba los datos que envía el usuario
* **practica1-saludo.php**. Saludo resultado si todo va bien


